package com.example.monan;

public class BanAn {
    public int maban;
    public String tenban;

    public BanAn(int maban, String tenban) {
        this.maban = maban;
        this.tenban = tenban;
    }

    public int getMaban() {
        return maban;
    }

    public void setMaban(int maban) {
        this.maban = maban;
    }

    public String getTenban() {
        return tenban;
    }

    public void setTenban(String tenban) {
        this.tenban = tenban;
    }
}
